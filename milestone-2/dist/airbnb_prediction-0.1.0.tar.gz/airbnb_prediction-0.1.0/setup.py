# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

packages = \
['airbnb_prediction']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'airbnb-prediction',
    'version': '0.1.0',
    'description': 'A package for r predicting Airbnb property prices in Vancouver.',
    'long_description': '# Milestone 2: predicting Airbnb nightly price from property and host data\n\n[![Python](https://img.shields.io/badge/python-3.9-blue)]()\n[![codecov](https://codecov.io/gh/TomasBeuzen/airbnb_prediction/branch/main/graph/badge.svg)](https://codecov.io/gh/TomasBeuzen/airbnb_prediction)\n[![Documentation Status](https://readthedocs.org/projects/airbnb_prediction/badge/?version=latest)](https://airbnb_prediction.readthedocs.io/en/latest/?badge=latest)\n[![Build](https://github.com/TomasBeuzen/airbnb_prediction/workflows/build/badge.svg)](https://github.com/TomasBeuzen/airbnb_prediction/actions/workflows/build.yml)\n\nHere we provide a package, `airbnb_prediction`, containing functionality to build a regression model to predict the nightly price of Airbnb properties using characteristics of the property and host (price, bedrooms, host response rate, etc.).\n\n## Contents\n\nIn this project, we have abstracted code and documentation required to run our analysis into a package `airbnb_prediction`. As a result, our analysis is self-contained, transparent about dependencies, and easy to test and distribute (if desired).\n\n## Installation\n\nThe package can be installed using `poetry`:\n\n    ```bash\n    poetry install\n    ```\n\n### Rendering report and documentation\n\nFunctionality of `airbnb_prediction` is demonstrated in the documentation, which can be found at: `docs/_build/html/index.html`.\n\nTo build the documentation from source, run the following from the project root:\n\n    ```bash\n    make html -C docs\n    ```\n\n### Running tests\n\nTo run package tests, run the following from the project root:\n\n    ```sh\n    pytest tests/\n    ```\n\n## Dependencies\n\nDependencies are listed in the `pyproject.toml` file. The exact versions of all dependencies used to develop the package in its current state are listed in `poetry.lock`.\n\n## Contributors\n\nWe welcome and recognize all contributions. You can see a list of current contributors in the [contributors tab](https://github.com/TomasBeuzen/airbnb_prediction/graphs/contributors).\n\n### Credits\n\nThis package was created with Cookiecutter and the UBC-MDS/cookiecutter-ubc-mds project template, modified from the [pyOpenSci/cookiecutter-pyopensci](https://github.com/pyOpenSci/cookiecutter-pyopensci) project template and the [audreyr/cookiecutter-pypackage](https://github.com/audreyr/cookiecutter-pypackage).\n',
    'author': 'Tomas Beuzen',
    'author_email': None,
    'maintainer': None,
    'maintainer_email': None,
    'url': 'https://github.com/TomasBeuzen/airbnb_prediction',
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
