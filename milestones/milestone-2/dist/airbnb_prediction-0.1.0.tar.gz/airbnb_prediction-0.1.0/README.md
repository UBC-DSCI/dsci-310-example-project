# Airbnb Prediction 

[![Python](https://img.shields.io/badge/python-3.9-blue)]()
[![codecov](https://codecov.io/gh/TomasBeuzen/airbnb_prediction/branch/main/graph/badge.svg)](https://codecov.io/gh/TomasBeuzen/airbnb_prediction)
[![Documentation Status](https://readthedocs.org/projects/airbnb_prediction/badge/?version=latest)](https://airbnb_prediction.readthedocs.io/en/latest/?badge=latest)
[![Build](https://github.com/TomasBeuzen/airbnb_prediction/workflows/build/badge.svg)](https://github.com/TomasBeuzen/airbnb_prediction/actions/workflows/build.yml)


## Installation

```bash
$ pip install -i https://test.pypi.org/simple/ airbnb_prediction
```

## Features

- TODO

## Dependencies

- TODO

## Usage

- TODO

## Documentation

The official documentation is hosted on Read the Docs: https://airbnb_prediction.readthedocs.io/en/latest/

## Contributors

We welcome and recognize all contributions. You can see a list of current contributors in the [contributors tab](https://github.com/TomasBeuzen/airbnb_prediction/graphs/contributors).

### Credits

This package was created with Cookiecutter and the UBC-MDS/cookiecutter-ubc-mds project template, modified from the [pyOpenSci/cookiecutter-pyopensci](https://github.com/pyOpenSci/cookiecutter-pyopensci) project template and the [audreyr/cookiecutter-pypackage](https://github.com/audreyr/cookiecutter-pypackage).
